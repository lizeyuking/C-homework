// BttnGroupDoc.cpp : implementation of the CBttnGroupDoc class
//

#include "stdafx.h"
#include "BttnGroup.h"

#include "BttnGroupDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBttnGroupDoc

IMPLEMENT_DYNCREATE(CBttnGroupDoc, CDocument)

BEGIN_MESSAGE_MAP(CBttnGroupDoc, CDocument)
	//{{AFX_MSG_MAP(CBttnGroupDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBttnGroupDoc construction/destruction

CBttnGroupDoc::CBttnGroupDoc()
{
	// TODO: add one-time construction code here

}

CBttnGroupDoc::~CBttnGroupDoc()
{
}

BOOL CBttnGroupDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CBttnGroupDoc serialization

void CBttnGroupDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBttnGroupDoc diagnostics

#ifdef _DEBUG
void CBttnGroupDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CBttnGroupDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBttnGroupDoc commands
