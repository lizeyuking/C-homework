// MCIWndPlayerDlg.h : header file
//

#if !defined(AFX_MCIWNDPLAYERDLG_H__E30E897F_6D01_42F4_BC93_E44A49112169__INCLUDED_)
#define AFX_MCIWNDPLAYERDLG_H__E30E897F_6D01_42F4_BC93_E44A49112169__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "vfw.h"

/////////////////////////////////////////////////////////////////////////////
// CMCIWndPlayerDlg dialog

class CMCIWndPlayerDlg : public CDialog
{
// Construction
public:
	CMCIWndPlayerDlg(CWnd* pParent = NULL);	// standard constructor


// Dialog Data
	//{{AFX_DATA(CMCIWndPlayerDlg)
	enum { IDD = IDD_MCIWNDPLAYER_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMCIWndPlayerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMCIWndPlayerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	HWND  m_hMciWnd;

public:
	void ShowMCIWnd(CString szFile);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MCIWNDPLAYERDLG_H__E30E897F_6D01_42F4_BC93_E44A49112169__INCLUDED_)
