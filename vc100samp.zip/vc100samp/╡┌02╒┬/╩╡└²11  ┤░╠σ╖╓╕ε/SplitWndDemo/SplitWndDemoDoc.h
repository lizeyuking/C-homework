// SplitWndDemoDoc.h : interface of the CSplitWndDemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPLITWNDDEMODOC_H__A27EEC7F_5A32_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_SPLITWNDDEMODOC_H__A27EEC7F_5A32_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CSplitWndDemoDoc : public CDocument
{
protected: // create from serialization only
	CSplitWndDemoDoc();
	DECLARE_DYNCREATE(CSplitWndDemoDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSplitWndDemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSplitWndDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSplitWndDemoDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPLITWNDDEMODOC_H__A27EEC7F_5A32_11D6_8F32_00E04CE76240__INCLUDED_)
