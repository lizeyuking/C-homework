// SplitWndDemoView.cpp : implementation of the CSplitWndDemoView class
//

#include "stdafx.h"
#include "SplitWndDemo.h"

#include "SplitWndDemoDoc.h"
#include "SplitWndDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSplitWndDemoView

IMPLEMENT_DYNCREATE(CSplitWndDemoView, CView)

BEGIN_MESSAGE_MAP(CSplitWndDemoView, CView)
	//{{AFX_MSG_MAP(CSplitWndDemoView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSplitWndDemoView construction/destruction

CSplitWndDemoView::CSplitWndDemoView()
{
	// TODO: add construction code here

}

CSplitWndDemoView::~CSplitWndDemoView()
{
}

BOOL CSplitWndDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSplitWndDemoView drawing

void CSplitWndDemoView::OnDraw(CDC* pDC)
{
//	CSplitWndDemoDoc* pDoc = GetDocument();
//	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSplitWndDemoView printing

BOOL CSplitWndDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSplitWndDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSplitWndDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSplitWndDemoView diagnostics

#ifdef _DEBUG
void CSplitWndDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CSplitWndDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

/*CSplitWndDemoDoc* CSplitWndDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSplitWndDemoDoc)));
	return (CSplitWndDemoDoc*)m_pDocument;
}*/
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSplitWndDemoView message handlers
