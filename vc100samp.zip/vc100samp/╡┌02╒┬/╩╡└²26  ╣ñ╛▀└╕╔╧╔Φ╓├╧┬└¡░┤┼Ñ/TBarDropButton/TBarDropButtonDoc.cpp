// TBarDropButtonDoc.cpp : implementation of the CTBarDropButtonDoc class
//

#include "stdafx.h"
#include "TBarDropButton.h"

#include "TBarDropButtonDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonDoc

IMPLEMENT_DYNCREATE(CTBarDropButtonDoc, CDocument)

BEGIN_MESSAGE_MAP(CTBarDropButtonDoc, CDocument)
	//{{AFX_MSG_MAP(CTBarDropButtonDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonDoc construction/destruction

CTBarDropButtonDoc::CTBarDropButtonDoc()
{
	// TODO: add one-time construction code here

}

CTBarDropButtonDoc::~CTBarDropButtonDoc()
{
}

BOOL CTBarDropButtonDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonDoc serialization

void CTBarDropButtonDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonDoc diagnostics

#ifdef _DEBUG
void CTBarDropButtonDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTBarDropButtonDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonDoc commands
