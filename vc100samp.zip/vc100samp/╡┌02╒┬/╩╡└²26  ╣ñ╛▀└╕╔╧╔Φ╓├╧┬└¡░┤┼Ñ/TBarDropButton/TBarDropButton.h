// TBarDropButton.h : main header file for the TBARDROPBUTTON application
//

#if !defined(AFX_TBARDROPBUTTON_H__31E73E13_6129_11D6_9E62_CA858095501B__INCLUDED_)
#define AFX_TBARDROPBUTTON_H__31E73E13_6129_11D6_9E62_CA858095501B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonApp:
// See TBarDropButton.cpp for the implementation of this class
//

class CTBarDropButtonApp : public CWinApp
{
public:
	CTBarDropButtonApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTBarDropButtonApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTBarDropButtonApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBARDROPBUTTON_H__31E73E13_6129_11D6_9E62_CA858095501B__INCLUDED_)
