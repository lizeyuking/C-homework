// TBarDropButtonView.cpp : implementation of the CTBarDropButtonView class
//

#include "stdafx.h"
#include "TBarDropButton.h"

#include "TBarDropButtonDoc.h"
#include "TBarDropButtonView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonView

IMPLEMENT_DYNCREATE(CTBarDropButtonView, CView)

BEGIN_MESSAGE_MAP(CTBarDropButtonView, CView)
	//{{AFX_MSG_MAP(CTBarDropButtonView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonView construction/destruction

CTBarDropButtonView::CTBarDropButtonView()
{
	// TODO: add construction code here

}

CTBarDropButtonView::~CTBarDropButtonView()
{
}

BOOL CTBarDropButtonView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonView drawing

void CTBarDropButtonView::OnDraw(CDC* pDC)
{
	CTBarDropButtonDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonView printing

BOOL CTBarDropButtonView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTBarDropButtonView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTBarDropButtonView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonView diagnostics

#ifdef _DEBUG
void CTBarDropButtonView::AssertValid() const
{
	CView::AssertValid();
}

void CTBarDropButtonView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTBarDropButtonDoc* CTBarDropButtonView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTBarDropButtonDoc)));
	return (CTBarDropButtonDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTBarDropButtonView message handlers
