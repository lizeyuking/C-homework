// MoveSelObView.cpp : implementation of the CMoveSelObView class
//

#include "stdafx.h"
#include "MoveSelOb.h"

#include "MoveSelObDoc.h"
#include "MoveSelObView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObView

IMPLEMENT_DYNCREATE(CMoveSelObView, CScrollView)

BEGIN_MESSAGE_MAP(CMoveSelObView, CScrollView)
	//{{AFX_MSG_MAP(CMoveSelObView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObView construction/destruction

CMoveSelObView::CMoveSelObView() : m_sizeEllipse(100, -100),
								   m_pointTopLeft(0, 0),
								   m_sizeOffset(0, 0)

{

    m_bCaptured = FALSE;

}

CMoveSelObView::~CMoveSelObView()
{
}

BOOL CMoveSelObView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObView drawing

void CMoveSelObView::OnDraw(CDC* pDC)
{
	CMoveSelObDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//������ɫ��ˢ
	CBrush brushHatch(HS_DIAGCROSS, RGB(255, 0, 0));
    CPoint point(0, 0);                  

	//ת���߼����굽�豸����
    pDC->LPtoDP(&point);                 
    pDC->SetBrushOrg(point);             
    CBrush* pOldBrush = pDC->SelectObject(&brushHatch);
	//����ɫԲȦ
    pDC->Ellipse(CRect(m_pointTopLeft, m_sizeEllipse));
	pDC->SelectObject(pOldBrush);
	// TODO: add draw code for native data here
}

void CMoveSelObView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	//���ù�����Χ
	CSize sizeTotal(800, 1050); // 8-by-10.5 inches
    CSize sizePage(sizeTotal.cx / 2, sizeTotal.cy / 2);
    CSize sizeLine(sizeTotal.cx / 50, sizeTotal.cy / 50);
    SetScrollSizes(MM_LOENGLISH, sizeTotal, sizePage, sizeLine);

}

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObView printing

BOOL CMoveSelObView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMoveSelObView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMoveSelObView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObView diagnostics

#ifdef _DEBUG
void CMoveSelObView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMoveSelObView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CMoveSelObDoc* CMoveSelObView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMoveSelObDoc)));
	return (CMoveSelObDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObView message handlers

void CMoveSelObView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CRect rectEllipse(m_pointTopLeft, m_sizeEllipse); 
    CRgn  circle;

    CClientDC dc(this);
    OnPrepareDC(&dc);
    dc.LPtoDP(rectEllipse); 
    circle.CreateEllipticRgnIndirect(rectEllipse);
    if (circle.PtInRegion(point)) {
        //��׽���
        SetCapture();
        m_bCaptured = TRUE;
        CPoint pointTopLeft(m_pointTopLeft);
        dc.LPtoDP(&pointTopLeft);
        m_sizeOffset = point - pointTopLeft; 

        //���ù����״Ϊʮ��״
        ::SetCursor(::LoadCursor(NULL, IDC_CROSS));
    }

	CScrollView::OnLButtonDown(nFlags, point);
}

void CMoveSelObView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if (m_bCaptured) {
		//�ͷ���겶׽
        ::ReleaseCapture();
        m_bCaptured = FALSE;
    }

	CScrollView::OnLButtonUp(nFlags, point);
}

void CMoveSelObView::OnMouseMove(UINT nFlags, CPoint point) 
{
	
    if (m_bCaptured) {
		//�����ͼ�α�ѡ�У�������걻��׽�����ͼ��λ��
        CClientDC dc(this);
        OnPrepareDC(&dc);
        CRect rectOld(m_pointTopLeft, m_sizeEllipse);
        dc.LPtoDP(rectOld);
		//������λ�õ�ͼ��
        InvalidateRect(rectOld, TRUE);
        m_pointTopLeft = point - m_sizeOffset;
        dc.DPtoLP(&m_pointTopLeft);
		//����λ�û�ͼ��
        CRect rectNew(m_pointTopLeft, m_sizeEllipse);
        dc.LPtoDP(rectNew);
        InvalidateRect(rectNew, TRUE);
    }

	
	CScrollView::OnMouseMove(nFlags, point);
}
