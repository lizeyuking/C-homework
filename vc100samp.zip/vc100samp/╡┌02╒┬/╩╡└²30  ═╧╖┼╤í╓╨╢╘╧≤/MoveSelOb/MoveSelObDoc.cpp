// MoveSelObDoc.cpp : implementation of the CMoveSelObDoc class
//

#include "stdafx.h"
#include "MoveSelOb.h"

#include "MoveSelObDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObDoc

IMPLEMENT_DYNCREATE(CMoveSelObDoc, CDocument)

BEGIN_MESSAGE_MAP(CMoveSelObDoc, CDocument)
	//{{AFX_MSG_MAP(CMoveSelObDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObDoc construction/destruction

CMoveSelObDoc::CMoveSelObDoc()
{
	// TODO: add one-time construction code here

}

CMoveSelObDoc::~CMoveSelObDoc()
{
}

BOOL CMoveSelObDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMoveSelObDoc serialization

void CMoveSelObDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObDoc diagnostics

#ifdef _DEBUG
void CMoveSelObDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMoveSelObDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMoveSelObDoc commands
