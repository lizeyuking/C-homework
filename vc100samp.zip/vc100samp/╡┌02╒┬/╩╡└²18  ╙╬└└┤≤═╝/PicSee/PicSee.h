// PicSee.h : main header file for the PICSEE application
//

#if !defined(AFX_PICSEE_H__FE9503E5_6B76_11D6_9E62_EA3320C3730D__INCLUDED_)
#define AFX_PICSEE_H__FE9503E5_6B76_11D6_9E62_EA3320C3730D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CPicSeeApp:
// See PicSee.cpp for the implementation of this class
//

class CPicSeeApp : public CWinApp
{
public:
	CPicSeeApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPicSeeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CPicSeeApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICSEE_H__FE9503E5_6B76_11D6_9E62_EA3320C3730D__INCLUDED_)
