// PicSeeView.cpp : implementation of the CPicSeeView class
//

#include "stdafx.h"
#include "PicSee.h"

#include "PicSeeDoc.h"
#include "PicSeeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPicSeeView

IMPLEMENT_DYNCREATE(CPicSeeView, CScrollView)

BEGIN_MESSAGE_MAP(CPicSeeView, CScrollView)
	//{{AFX_MSG_MAP(CPicSeeView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPicSeeView construction/destruction

CPicSeeView::CPicSeeView()
{
	// TODO: add construction code here
	SetScrollSizes(MM_TEXT, CSize(0, 0));

}

CPicSeeView::~CPicSeeView()
{
}

BOOL CPicSeeView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPicSeeView drawing

void CPicSeeView::OnDraw(CDC* pDC)
{
	CPicSeeDoc* pDoc = GetDocument();
	BITMAP BitMap;
	CDC DCMem;
	// Do not call CWnd::OnPaint() for painting messages
	ASSERT_VALID(pDoc);
	if (!pDoc->GetHandle())
		return;
	//�����ڴ��豸����
	if (!DCMem.CreateCompatibleDC(pDC))
		TRACE0("DCMem.CreateCompatibleDC failed\n");
	pDoc->SelectBitmap(&DCMem);
	pDoc->GetBitmap(&BitMap);
	//��λͼ��������ʾ�豸�����У�������ʾ
	if (!pDC->BitBlt(0, 0, BitMap.bmWidth, BitMap.bmHeight, &DCMem, 0, 0, SRCCOPY))
		TRACE0("BitBlt failed\n");
	pDoc->SelectOldBitmap(&DCMem);
	DCMem.DeleteDC();
}

/*void CPicSeeView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = sizeTotal.cy = 100;
	SetScrollSizes(MM_TEXT, sizeTotal);
}
*/
/////////////////////////////////////////////////////////////////////////////
// CPicSeeView printing

BOOL CPicSeeView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPicSeeView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPicSeeView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CPicSeeView diagnostics

#ifdef _DEBUG
void CPicSeeView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CPicSeeView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CPicSeeDoc* CPicSeeView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPicSeeDoc)));
	return (CPicSeeDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPicSeeView message handlers

void CPicSeeView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CPicSeeDoc* pDoc = GetDocument();
	//���������ָ��
	CFrameWnd* pParentFrame = GetParentFrame();
	BITMAP BitMap;
	if (!pDoc->GetHandle())
		return;
	//���λͼ�ṹ
	pDoc->GetBitmap(&BitMap);
	//���ù�������Χ
	SetScrollSizes(MM_TEXT, CSize(BitMap.bmWidth, BitMap.bmHeight));
	//���¹滮�����ڴ�С
	pParentFrame->RecalcLayout();
	ResizeParentToFit();	
}
