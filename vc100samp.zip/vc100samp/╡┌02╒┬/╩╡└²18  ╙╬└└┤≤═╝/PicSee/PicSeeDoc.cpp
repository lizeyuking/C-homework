// PicSeeDoc.cpp : implementation of the CPicSeeDoc class
//

#include "stdafx.h"
#include "PicSee.h"

#include "PicSeeDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPicSeeDoc

IMPLEMENT_DYNCREATE(CPicSeeDoc, CDocument)

BEGIN_MESSAGE_MAP(CPicSeeDoc, CDocument)
	//{{AFX_MSG_MAP(CPicSeeDoc)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPicSeeDoc construction/destruction

CPicSeeDoc::CPicSeeDoc()
{
	// TODO: add one-time construction code here

}

CPicSeeDoc::~CPicSeeDoc()
{
}

BOOL CPicSeeDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPicSeeDoc serialization

void CPicSeeDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPicSeeDoc diagnostics

#ifdef _DEBUG
void CPicSeeDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPicSeeDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPicSeeDoc commands

void CPicSeeDoc::OnFileNew() 
{
	//�����κι���
}
void CPicSeeDoc::DeleteContents() 
{
	//���λͼ��Դ
	if (m_Bitmap.m_hObject != NULL)
		m_Bitmap.DeleteObject();

	CDocument::DeleteContents();
}


BOOL CPicSeeDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
/*	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
		
	return TRUE;*/

	if (IsModified())
		TRACE0("Warning: OnOpenDocument replaces an unsaved document\n");
	DeleteContents();
	//���õȴ����
	BeginWaitCursor();
	//��λͼ�ļ�
	HBITMAP hImage = (HBITMAP)LoadImage(NULL, lpszPathName, IMAGE_BITMAP,
		0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
	EndWaitCursor();
	if (!hImage) {
		DWORD LastError = GetLastError();
		// Error message should be fomatted with LastError included
		AfxMessageBox("LoadImage failed");
		return FALSE;
	}
	//����λͼ����
	if (!m_Bitmap.Attach(hImage)) {
		AfxMessageBox("Bitmap could not be attached");
		return FALSE;
	}
	SetModifiedFlag(FALSE);
	//����������ͼ
	UpdateAllViews(NULL);
	return TRUE;

}
