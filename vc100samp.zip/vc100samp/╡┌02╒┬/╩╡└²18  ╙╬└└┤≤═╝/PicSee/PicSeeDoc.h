// PicSeeDoc.h : interface of the CPicSeeDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PICSEEDOC_H__FE9503ED_6B76_11D6_9E62_EA3320C3730D__INCLUDED_)
#define AFX_PICSEEDOC_H__FE9503ED_6B76_11D6_9E62_EA3320C3730D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPicSeeDoc : public CDocument
{
protected: // create from serialization only
	CPicSeeDoc();
	DECLARE_DYNCREATE(CPicSeeDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPicSeeDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPicSeeDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	HBITMAP GetHandle() const {return (HBITMAP)m_Bitmap.m_hObject;};
	void SelectOldBitmap(CDC *pDCMem) {pDCMem->SelectObject(m_pOldBitmap);};
	void SelectBitmap(CDC *pDCMem)
		{m_pOldBitmap=pDCMem->SelectObject(&m_Bitmap);};
	int GetBitmap(BITMAP* pBitMap) {return m_Bitmap.GetBitmap(pBitMap);};
protected:
	CBitmap m_Bitmap;
	CBitmap* m_pOldBitmap;
// Generated message map functions
protected:
	//{{AFX_MSG(CPicSeeDoc)
	afx_msg void OnFileNew();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICSEEDOC_H__FE9503ED_6B76_11D6_9E62_EA3320C3730D__INCLUDED_)
