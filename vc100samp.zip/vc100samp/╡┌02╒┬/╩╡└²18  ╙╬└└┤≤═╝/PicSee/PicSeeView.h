// PicSeeView.h : interface of the CPicSeeView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PICSEEVIEW_H__FE9503EF_6B76_11D6_9E62_EA3320C3730D__INCLUDED_)
#define AFX_PICSEEVIEW_H__FE9503EF_6B76_11D6_9E62_EA3320C3730D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPicSeeView : public CScrollView
{
protected: // create from serialization only
	CPicSeeView();
	DECLARE_DYNCREATE(CPicSeeView)

// Attributes
public:
	CPicSeeDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPicSeeView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPicSeeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPicSeeView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in PicSeeView.cpp
inline CPicSeeDoc* CPicSeeView::GetDocument()
   { return (CPicSeeDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICSEEVIEW_H__FE9503EF_6B76_11D6_9E62_EA3320C3730D__INCLUDED_)
