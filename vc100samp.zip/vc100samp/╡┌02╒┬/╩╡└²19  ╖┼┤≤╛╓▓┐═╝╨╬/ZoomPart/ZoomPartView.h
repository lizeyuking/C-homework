// ZoomPartView.h : interface of the CZoomPartView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZOOMPARTVIEW_H__28182EED_735B_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_ZOOMPARTVIEW_H__28182EED_735B_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CZoomPartView : public CView
{
protected: // create from serialization only
	CZoomPartView();
	DECLARE_DYNCREATE(CZoomPartView)

// Attributes
public:
	CZoomPartDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZoomPartView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CZoomPartView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CSize m_sizeDest;			
	CSize m_sizeSource;
	CBitmap * m_pBitmap;
	CDC * m_pdcMem;
	int oldx,oldy,s,d;   //sȷ�����Ŵ�����,dȷ���Ŵ���ʾ���򣬷Ŵ���=d/s
	bool recover;
	long mana;


// Generated message map functions
protected:
	//{{AFX_MSG(CZoomPartView)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ZoomPartView.cpp
inline CZoomPartDoc* CZoomPartView::GetDocument()
   { return (CZoomPartDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZOOMPARTVIEW_H__28182EED_735B_11D6_8F32_00E04CE76240__INCLUDED_)
