// ZoomPartDoc.h : interface of the CZoomPartDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZOOMPARTDOC_H__28182EEB_735B_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_ZOOMPARTDOC_H__28182EEB_735B_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CZoomPartDoc : public CDocument
{
protected: // create from serialization only
	CZoomPartDoc();
	DECLARE_DYNCREATE(CZoomPartDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZoomPartDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CZoomPartDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CZoomPartDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZOOMPARTDOC_H__28182EEB_735B_11D6_8F32_00E04CE76240__INCLUDED_)
