// ZoomPartView.cpp : implementation of the CZoomPartView class
//

#include "stdafx.h"
#include "ZoomPart.h"

#include "ZoomPartDoc.h"
#include "ZoomPartView.h"
#include "MainFrm.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CZoomPartView

IMPLEMENT_DYNCREATE(CZoomPartView, CView)

BEGIN_MESSAGE_MAP(CZoomPartView, CView)
	//{{AFX_MSG_MAP(CZoomPartView)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZoomPartView construction/destruction

CZoomPartView::CZoomPartView()
{
	// TODO: add construction code here
	m_pdcMem = new CDC;
	m_pBitmap = new CBitmap;
	recover = true;
	s = 30; d = 45;
	mana = SRCCOPY;

}

CZoomPartView::~CZoomPartView()
{
	delete m_pdcMem;
	delete m_pBitmap;
}

BOOL CZoomPartView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CZoomPartView drawing

void CZoomPartView::OnDraw(CDC* pDC)
{
	CZoomPartDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	//�����ж��Ƿ�loadλͼ�ľ�̬��־
	static bool load;
	//��ԭ����С��ʾλͼ
	if (!load) {
		BITMAP bm;
		load = !load;
		m_pBitmap->LoadBitmap(IDB_BITMAP1);
		m_pdcMem->CreateCompatibleDC(pDC);
		m_pdcMem->SelectObject(m_pBitmap);
		m_pBitmap->GetObject(sizeof(bm),&bm);
		m_sizeSource.cx = bm.bmWidth;
		m_sizeSource.cy = bm.bmHeight;
		m_sizeDest = m_sizeSource;
		pDC->StretchBlt(0,0,m_sizeSource.cx,m_sizeSource.cy,
			m_pdcMem,0,0,m_sizeSource.cx,m_sizeSource.cy,mana);
	}
	else {
		pDC->StretchBlt(0,0,m_sizeSource.cx,m_sizeSource.cy,
			m_pdcMem,0,0,m_sizeSource.cx,m_sizeSource.cy,mana);
}

}

/////////////////////////////////////////////////////////////////////////////
// CZoomPartView printing

BOOL CZoomPartView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CZoomPartView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CZoomPartView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CZoomPartView diagnostics

#ifdef _DEBUG
void CZoomPartView::AssertValid() const
{
	CView::AssertValid();
}

void CZoomPartView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CZoomPartDoc* CZoomPartView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CZoomPartDoc)));
	return (CZoomPartDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CZoomPartView message handlers

void CZoomPartView::OnMouseMove(UINT nFlags, CPoint point) 
{
	//����Ҫ�Ŵ�ľֲ����ε�Դͼ��λ�ú�Ŀ��λ��
	CString cord;
	int dd;
    CRect srect,drect,mrect;
	srect.left = point.x - s;
	srect.top = point.y - s;
	srect.right = point.x + s;
	srect.bottom = point.y + s;
	
	drect.left = point.x - d;
	drect.top = point.y - d;
	drect.right = point.x + d;
	drect.bottom = point.y + d;
	
	mrect.left = oldx - d;
	mrect.top = oldy - d;
	mrect.right = oldx + d;
	mrect.bottom = oldy + d;
	dd = 2*d;
	CDC * pDC = GetDC();
	OnPrepareDC(pDC);
	//�Ŵ�ͼ��
	if (recover)
	{
		pDC->BitBlt(mrect.left,mrect.top,dd,dd,
			m_pdcMem,mrect.left,mrect.top,mana);
	}
	pDC->StretchBlt(drect.left,drect.top,
		drect.Width(),drect.Height(),m_pdcMem,srect.left,
		srect.top,srect.Width(),srect.Height(),SRCCOPY);
	oldx = point.x; oldy = point.y;
	ReleaseDC(pDC);
	
	recover = true;

	CView::OnMouseMove(nFlags, point);
}

void CZoomPartView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	//������λ�ò���λͼ�ϣ���ԭλͼ��С��ʾ
	CRect rc(0,0,m_sizeSource.cx,m_sizeSource.cy);
	if(!rc.PtInRect(point))
	{
		Invalidate();
	}
	else if (d > 5)//����Ŵ�������5���ͼ�����С�Ŵ�����Ȼ����зŴ���ʾ
	{
		CDC * pDC = GetDC();
		pDC->StretchBlt(oldx - d,oldy - d,2*d,
			2*d,m_pdcMem,oldx - d,oldy - d,2*d,2*d,mana);
		d -= 10;
		ReleaseDC(pDC);
		CZoomPartView::OnMouseMove(nFlags, point);
	} 
	CView::OnLButtonDown(nFlags, point);
}

void CZoomPartView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	//������λ�ò���λͼ�ϣ���ԭλͼ��С��ʾ
	CRect rc(0,0,m_sizeSource.cx,m_sizeSource.cy);
	if(!rc.PtInRect(point))
	{
		Invalidate();
	}
	else if (d <150)//����Ŵ���С��150���ͼ������ӷŴ�����Ȼ����зŴ���ʾ
	{ 
		d += 10;
		CZoomPartView::OnMouseMove(nFlags, point); 
	} 
	CView::OnRButtonDown(nFlags, point);
}

				
