// CmmnDlgDemo.h : main header file for the CMMNDLGDEMO application
//

#if !defined(AFX_CMMNDLGDEMO_H__D10FBE85_774F_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_CMMNDLGDEMO_H__D10FBE85_774F_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCmmnDlgDemoApp:
// See CmmnDlgDemo.cpp for the implementation of this class
//

class CCmmnDlgDemoApp : public CWinApp
{
public:
	CCmmnDlgDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCmmnDlgDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCmmnDlgDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMMNDLGDEMO_H__D10FBE85_774F_11D6_8F32_00E04CE76240__INCLUDED_)
