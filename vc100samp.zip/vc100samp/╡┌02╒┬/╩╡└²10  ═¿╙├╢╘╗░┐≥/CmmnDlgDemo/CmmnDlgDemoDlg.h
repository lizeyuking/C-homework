// CmmnDlgDemoDlg.h : header file
//

#if !defined(AFX_CMMNDLGDEMODLG_H__D10FBE87_774F_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_CMMNDLGDEMODLG_H__D10FBE87_774F_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCmmnDlgDemoDlg dialog

class CCmmnDlgDemoDlg : public CDialog
{
// Construction
public:
	CCmmnDlgDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCmmnDlgDemoDlg)
	enum { IDD = IDD_CMMNDLGDEMO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCmmnDlgDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	LOGFONT m_LogFont;
	COLORREF m_clrTxtColor;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCmmnDlgDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnFont();
	afx_msg void OnColor();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMMNDLGDEMODLG_H__D10FBE87_774F_11D6_8F32_00E04CE76240__INCLUDED_)
