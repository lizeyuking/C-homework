
#include "stdafx.h"
#include "ColorPickerCB.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



//  ����ɫ�����ƽṹ���鸳ֵ
SColorAndName	CColorPickerCB::ms_pColors[ CCB_MAX_COLORS ] =
{
	SColorAndName( RGB( 0x00, 0x00, 0x00 ),	"Black" ),
	SColorAndName( RGB( 0x80, 0x00, 0x00 ),	"Maroon" ),
	SColorAndName( RGB( 0x00, 0x80, 0x00 ),	"Green" ),
	SColorAndName( RGB( 0x80, 0x80, 0x00 ),	"Olive" ),
	SColorAndName( RGB( 0x00, 0x00, 0x80 ),	"Navy" ),
	SColorAndName( RGB( 0x80, 0x00, 0x80 ),	"Purple" ),
	SColorAndName( RGB( 0x00, 0x80, 0x80 ),	"Teal" ),
	SColorAndName( RGB( 0x80, 0x80, 0x80 ),	"Grey" ),
	SColorAndName( RGB( 0xC0, 0xC0, 0xC0 ),	"Silver" ),
	SColorAndName( RGB( 0xFF, 0x00, 0x00 ),	"Red" ),
	SColorAndName( RGB( 0x00, 0xFF, 0x00 ),	"Lime" ),
	SColorAndName( RGB( 0xFF, 0xFF, 0x00 ),	"Yellow" ),
	SColorAndName( RGB( 0x00, 0x00, 0xFF ),	"Blue" ),
	SColorAndName( RGB( 0xFF, 0x00, 0xFF ),	"Fushcia" ),
	SColorAndName( RGB( 0x00, 0xFF, 0xFF ),	"Aqua" ),
	SColorAndName( RGB( 0xFF, 0xFF, 0xFF ),	"White" ),
};


CColorPickerCB::CColorPickerCB()
{
	m_bInitialized = false;
}


CColorPickerCB::~CColorPickerCB()
{
}


BEGIN_MESSAGE_MAP(CColorPickerCB, CComboBox)
	//{{AFX_MSG_MAP(CColorPickerCB)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorPickerCB message handlers

int CColorPickerCB::OnCreate( LPCREATESTRUCT pCStruct ) 
{
	if( CComboBox::OnCreate( pCStruct ) == -1 )				
		return( -1 );										

	return( 0 );											
}


void CColorPickerCB::PreSubclassWindow() 
{
	// Initialize Contents
	Initialize();											
	
	// Subclass Control
	CComboBox::PreSubclassWindow();							

	// Select First Item By Default
	SetCurSel( 0 );											

	return;
}

//��ʼ���б��򣬽���ɫֵ�����Ƹ�����
void CColorPickerCB::Initialize( void )
{
	int		iAddedItem = -1;

	// If Already Initialized
	if( m_bInitialized )									
		return;												

	// For All Colors
	for( int iColor = 0; iColor < CCB_MAX_COLORS; iColor++ )
	{
		// Set Color Name/Text
		iAddedItem = AddString(	ms_pColors[iColor].m_cColor );					
		if( iAddedItem == CB_ERRSPACE )						
			break;											
		else												
			// Set Color RGB Value
			SetItemData( iAddedItem, ms_pColors[
					iColor ].m_crColor );					
	}
	// Set Initialized Flag
	m_bInitialized = true;									
}

//�����б������ɫֵ�������ػ��б���
void CColorPickerCB::DrawItem( LPDRAWITEMSTRUCT pDIStruct )
{
	static		CString	sColor;								

	CDC			dcContext;
	CRect		rItemRect( pDIStruct -> rcItem );
	CRect		rBlockRect( rItemRect );
	CRect		rTextRect( rBlockRect );
	CBrush		brFrameBrush;
	int			iFourthWidth = 0;
	int			iItem = pDIStruct -> itemID;
	int			iAction = pDIStruct -> itemAction;
	int			iState = pDIStruct -> itemState;
	COLORREF	crColor = 0;
	COLORREF	crNormal = GetSysColor( COLOR_WINDOW );
	COLORREF	crSelected = GetSysColor( COLOR_HIGHLIGHT );
	COLORREF	crText = GetSysColor( COLOR_WINDOWTEXT );

	// ��ϵ CDC����
	if( !dcContext.Attach( pDIStruct -> hDC ) )				
		return;			

	//���1/4���б������
	iFourthWidth = ( rBlockRect.Width() / 4 );				
	//������ɫ��ˢ
	brFrameBrush.CreateStockObject( BLACK_BRUSH );			

	//�������Ŀ��ѡ��
	if( iState & ODS_SELECTED )								
	{										
		
		dcContext.SetTextColor(
				( 0x00FFFFFF & ~( crText ) ) );				
		dcContext.SetBkColor( crSelected );					
		dcContext.FillSolidRect( &rBlockRect, crSelected );	
	}
	else//���û�б�ѡ��
	{
		dcContext.SetTextColor( crText );					
		dcContext.SetBkColor( crNormal );					
		dcContext.FillSolidRect( &rBlockRect, crNormal );	
	}
	//���������ڽ���״̬
	if( iState & ODS_FOCUS )								
		dcContext.DrawFocusRect( &rItemRect );				

	//������������
	rTextRect.left += ( iFourthWidth + 2 );					
	rTextRect.top += 2;										
	
	//����ͼ������
	rBlockRect.DeflateRect( CSize( 2, 2 ) );				
	rBlockRect.right = iFourthWidth;						
	
	//��ʾ����(��ɫ��)
	if( iItem != -1 )										
	{
		GetLBText( iItem, sColor );							

		//������ڲ�����״̬
		if( iState & ODS_DISABLED )							
		{
			crColor = GetSysColor( COLOR_INACTIVECAPTIONTEXT );
			dcContext.SetTextColor( crColor );				
		}
		else //�������һ��״̬
			crColor = GetItemData( iItem );					

		dcContext.SetBkMode( TRANSPARENT );				

		dcContext.TextOut( rTextRect.left, rTextRect.top,sColor );									

		//�����ɫ����
		dcContext.FillSolidRect( &rBlockRect, crColor );	
		
		//���߿�
		dcContext.FrameRect( &rBlockRect, &brFrameBrush );	
	}
	//����CDC����
	dcContext.Detach();										
}


//���ѡ�������ɫֵ
COLORREF CColorPickerCB::GetSelectedColorValue( void )
{
	//���ѡ�����Ŀ����
	int		iSelectedItem = GetCurSel();					

	//���û�б�ѡ��
	if( iSelectedItem == CB_ERR )							
		return( RGB( 0, 0, 0 ) );	// Return Black

	return( GetItemData( iSelectedItem ) );	
}

//���ѡ�������ɫ����
CString		CColorPickerCB::GetSelectedColorName( void )
{
	//���ѡ�����Ŀ����
	int		iSelectedItem = GetCurSel();					

	//���û�б�ѡ��
	if( iSelectedItem == CB_ERR )							
		return( m_sColorName = afxEmptyString ); 

	GetLBText( iSelectedItem, m_sColorName );				

	return( m_sColorName );									
}

//�趨ָ����ɫֵ��Ӧ���б������ɫֵ
void		CColorPickerCB::SetSelectedColorValue( COLORREF crClr )
{
	int		iItems = GetCount();
	
	for( int iItem = 0; iItem < iItems; iItem++ )
	{
		if( crClr == GetItemData( iItem ) )					
			SetCurSel( iItem );								
	}
	return;													
}


//�趨ָ����ɫ���ƶ�Ӧ�б��������
void		CColorPickerCB::SetSelectedColorName( PCSTR cpColor )
{
	int		iItems = GetCount();
	CString	sColorName;

	for( int iItem = 0; iItem < iItems; iItem++ )
	{
		GetLBText( iItem, sColorName );						

		if( !sColorName.CompareNoCase( cpColor ) )			
			SetCurSel( iItem );							
	}
}

//ɾ��ָ����ɫ���ƶ�Ӧ���б���
bool CColorPickerCB::RemoveColor( PCSTR cpColor )
{
	int		iItems = GetCount();
	CString	sColor;
	bool	bRemoved = false;

	for( int iItem = 0; iItem < iItems; iItem++ )
	{
		GetLBText( iItem, sColor );							
		if( !sColor.CompareNoCase( cpColor ) )				
		{
			DeleteString( iItem );							
			bRemoved = true;							
			break;										
		}
	}
	return( bRemoved );										
}

//ɾ��ָ����ɫֵ��Ӧ���б���
bool		CColorPickerCB::RemoveColor( COLORREF crClr )
{
	int		iItems = GetCount();
	bool	bRemoved = false;

	for( int iItem = 0; iItem < iItems; iItem++ )
	{
		if( crClr == GetItemData( iItem ) )					
		{
			DeleteString( iItem );							
			bRemoved = true;								
			break;											
		}
	}
	return( bRemoved );										
}

//����ָ����ɫ���ƺ���ɫֵ���б���
int			CColorPickerCB::AddColor( PCSTR cpName, COLORREF crColor )
{
	int		iItem = -1;

	iItem = InsertString( -1, cpName );						
	if( iItem != LB_ERR )								
		SetItemData( iItem, crColor );						

	return( iItem );										
}


	
