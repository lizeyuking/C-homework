// ColorSelCmb.h : main header file for the COLORSELCMB application
//

#if !defined(AFX_COLORSELCMB_H__31E73E05_6129_11D6_9E62_CA858095501B__INCLUDED_)
#define AFX_COLORSELCMB_H__31E73E05_6129_11D6_9E62_CA858095501B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CColorSelCmbApp:
// See ColorSelCmb.cpp for the implementation of this class
//

class CColorSelCmbApp : public CWinApp
{
public:
	CColorSelCmbApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorSelCmbApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CColorSelCmbApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORSELCMB_H__31E73E05_6129_11D6_9E62_CA858095501B__INCLUDED_)
