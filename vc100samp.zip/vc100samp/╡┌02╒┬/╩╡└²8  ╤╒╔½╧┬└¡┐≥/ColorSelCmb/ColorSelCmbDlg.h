// ColorSelCmbDlg.h : header file
//

#if !defined(AFX_COLORSELCMBDLG_H__31E73E07_6129_11D6_9E62_CA858095501B__INCLUDED_)
#define AFX_COLORSELCMBDLG_H__31E73E07_6129_11D6_9E62_CA858095501B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CColorSelCmbDlg dialog
#include "ColorPickerCB.h"

class CColorSelCmbDlg : public CDialog
{
// Construction
public:
	CColorSelCmbDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CColorSelCmbDlg)
	enum { IDD = IDD_COLORSELCMB_DIALOG };
	CColorPickerCB	m_cmbColorSel;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorSelCmbDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CColorSelCmbDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnGetname();
	afx_msg void OnGetvalue();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORSELCMBDLG_H__31E73E07_6129_11D6_9E62_CA858095501B__INCLUDED_)
