#if !defined(AFX_IMGWND_H__03C774F0_6584_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_IMGWND_H__03C774F0_6584_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImgWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CImgWnd window
#define STRECH_1_1		0
#define STRECH_FULL_X	1
#define STRECH_FULL_Y   2
#define STRECH_FULL		3
#define STRECH_CENTER   4

class CImgWnd : public CStatic
{
// Construction
public:
	CImgWnd();
	void SetImage(UINT resID);
	void SetStrechType(int nStrechType);
// Attributes
protected:
	CBitmap m_bmpImage;
	int m_nStrechType;
	CRect m_rcSrc;
	CRect m_rcDst;
// Operations
public:
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImgWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CImgWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CImgWnd)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMGWND_H__03C774F0_6584_11D6_8F32_00E04CE76240__INCLUDED_)
