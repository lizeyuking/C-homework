// ImgWnd.cpp : implementation file
//

#include "stdafx.h"
#include "ZoomImgDemo.h"
#include "ImgWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImgWnd

CImgWnd::CImgWnd()
{
	m_nStrechType = STRECH_1_1;
}

CImgWnd::~CImgWnd()
{
}


BEGIN_MESSAGE_MAP(CImgWnd, CStatic)
	//{{AFX_MSG_MAP(CImgWnd)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImgWnd message handlers
void CImgWnd::SetImage(UINT resID)
{
	m_bmpImage.LoadBitmap(resID);
}
void CImgWnd::SetStrechType(int nStrechType)
{
	m_nStrechType = nStrechType;

	//�ػ�
	Invalidate();
}
void CImgWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	//��ô��ڴ�С
	CRect r;
	GetClientRect(&r);

	//��䱳��
	HBRUSH brush = (HBRUSH)::GetStockObject(GRAY_BRUSH); 
	::FillRect(dc.m_hDC,&r,brush);
	dc.SetStretchBltMode(HALFTONE);

	//��λͼѡ���豸������
	CDC memdc;
	memdc.CreateCompatibleDC( &dc );
	CBitmap* pOldBmp= memdc.SelectObject(&m_bmpImage);
	
	//���λͼ����
	BITMAP bmp;
	m_bmpImage.GetBitmap(&bmp);

	//��ʼ����
	switch(m_nStrechType)
	{
	case STRECH_1_1://1:1
			dc.BitBlt(r.left,r.top,r.Width(),r.Height(),&memdc,0,0,SRCCOPY);
		break;
	case STRECH_FULL_X://������
		dc.StretchBlt(r.left,r.top,r.Width(),bmp.bmHeight,&memdc,0,0,
			bmp.bmWidth,bmp.bmHeight,SRCCOPY);
		break;
	case STRECH_FULL_Y://���߶�
		dc.StretchBlt(r.left,r.top,bmp.bmWidth,r.Height(),&memdc,0,0,
			bmp.bmWidth,bmp.bmHeight,SRCCOPY);
		break;
	case STRECH_FULL://��������
		dc.StretchBlt(r.left,r.top,r.Width(),r.Height(),&memdc,0,0,
			bmp.bmWidth,bmp.bmHeight,SRCCOPY);
		break;
	case STRECH_CENTER://������ʾ����СΪ���ڵ�һ��
		dc.StretchBlt(r.Width()/4,r.Height()/4,r.Width()/2,r.Height()/2,&memdc,0,0,
			bmp.bmWidth,bmp.bmHeight,SRCCOPY);
		break;
	}
	
	//��ԭ
	memdc.SelectObject(pOldBmp);
	
}
