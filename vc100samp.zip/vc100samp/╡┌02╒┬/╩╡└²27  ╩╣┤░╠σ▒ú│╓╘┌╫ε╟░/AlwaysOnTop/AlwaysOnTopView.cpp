// AlwaysOnTopView.cpp : implementation of the CAlwaysOnTopView class
//

#include "stdafx.h"
#include "AlwaysOnTop.h"

#include "AlwaysOnTopDoc.h"
#include "AlwaysOnTopView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAlwaysOnTopView

IMPLEMENT_DYNCREATE(CAlwaysOnTopView, CView)

BEGIN_MESSAGE_MAP(CAlwaysOnTopView, CView)
	//{{AFX_MSG_MAP(CAlwaysOnTopView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAlwaysOnTopView construction/destruction

CAlwaysOnTopView::CAlwaysOnTopView()
{
	// TODO: add construction code here

}

CAlwaysOnTopView::~CAlwaysOnTopView()
{
}

BOOL CAlwaysOnTopView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CAlwaysOnTopView drawing

void CAlwaysOnTopView::OnDraw(CDC* pDC)
{
	CAlwaysOnTopDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CAlwaysOnTopView printing

BOOL CAlwaysOnTopView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CAlwaysOnTopView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CAlwaysOnTopView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CAlwaysOnTopView diagnostics

#ifdef _DEBUG
void CAlwaysOnTopView::AssertValid() const
{
	CView::AssertValid();
}

void CAlwaysOnTopView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAlwaysOnTopDoc* CAlwaysOnTopView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAlwaysOnTopDoc)));
	return (CAlwaysOnTopDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAlwaysOnTopView message handlers
