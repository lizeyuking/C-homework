// MixColorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MixColor.h"
#include "MixColorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMixColorDlg dialog

CMixColorDlg::CMixColorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMixColorDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMixColorDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	//��ʼ������ֵ
	m_clrBackGround = GetSysColor(COLOR_MENU);
	m_clrTxt = GetSysColor(COLOR_MENUTEXT);
}

void CMixColorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMixColorDlg)
	DDX_Control(pDX, IDC_TXT, m_stcTxt);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMixColorDlg, CDialog)
	//{{AFX_MSG_MAP(CMixColorDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMixColorDlg message handlers

BOOL CMixColorDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//��ñ���ɫ��rgbֵ
	int nBackBlue = (m_clrBackGround>>16);
	int nBackGreen = (m_clrBackGround>>8)&0x0000FF;
	int nBackRed = m_clrBackGround&0x000000FF;
	
	//����ı���ɫ��rgbֵ
	int nTxtBlue = (m_clrTxt>>16);
	int nTxtGreen = (m_clrTxt>>8)&0x0000FF;
	int nTxtRed = m_clrTxt&0x000000FF;

	//��ù��������ڵ�ָ��
	CSliderCtrl* pTxtRed = (CSliderCtrl*)GetDlgItem(IDC_TXT_RED);
	CSliderCtrl* pTxtGreen = (CSliderCtrl*)GetDlgItem(IDC_TXT_GREEN);
	CSliderCtrl* pTxtBlue = (CSliderCtrl*)GetDlgItem(IDC_TXT_BLUE);
	CSliderCtrl* pBackRed = (CSliderCtrl*)GetDlgItem(IDC_BACK_RED);
	CSliderCtrl* pBackGreen = (CSliderCtrl*)GetDlgItem(IDC_BACK_GREEN);
	CSliderCtrl* pBackBlue = (CSliderCtrl*)GetDlgItem(IDC_BACK_BLUE);

	//�趨�������Ĺ�����Χ�ͳ�ʼλ��
	pTxtRed->SetRange(0,255);
	pTxtGreen->SetRange(0,255);
	pTxtBlue->SetRange(0,255);
	pTxtRed->SetPos(nTxtRed);
	pTxtGreen->SetPos(nTxtGreen);
	pTxtBlue->SetPos(nTxtBlue);

	pBackRed->SetRange(0,255);
	pBackGreen->SetRange(0,255);
	pBackBlue->SetRange(0,255);
	pBackRed->SetPos(nBackRed);
	pBackGreen->SetPos(nBackGreen);
	pBackBlue->SetPos(nBackBlue);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMixColorDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMixColorDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	if (IsIconic())
	{
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}

	//��þ�̬�ı���Ĵ���ָ������豸����
	CStatic* pTxt = (CStatic*)GetDlgItem(IDC_TXT);
	CDC* pDC = pTxt->GetDC();

	//��þ�̬�ı���Ŀͻ�����
	CRect rc;
	pTxt->GetClientRect(&rc);

	//�����������Ļ�ˢ����������䱳��
	CBrush brush;
	brush.CreateSolidBrush(m_clrBackGround);
	pDC->FillRect(&rc,&brush);

	//�趨���ֵ�ɫ�ʣ����������
	pDC->SetBkColor(m_clrBackGround);
	pDC->SetTextColor(m_clrTxt);
	pDC->DrawText("��ɫ����",&rc,DT_CENTER|DT_SINGLELINE|DT_VCENTER);
	pTxt->ReleaseDC(pDC);
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMixColorDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMixColorDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{	
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);

	//�����϶�����Ϣ������
	if( nSBCode != SB_THUMBTRACK)
		return;

	//��þ�̬�ı���Ŀͻ�����
	CStatic* pTxt = (CStatic*)GetDlgItem(IDC_TXT);
	CRect rc;
	pTxt->GetClientRect(&rc);

	//�ж��϶������ĸ���������Ȼ����ݹ������ĵ�ǰλ�øı��ı����ǰ��ɫ�ͱ���ɫ
	switch(pScrollBar->GetDlgCtrlID())
	{
	case IDC_TXT_BLUE:
		m_clrTxt = (m_clrTxt&0x0000FFFF)+(nPos<<16);
		break;
	case IDC_TXT_GREEN:
		m_clrTxt = (m_clrTxt&0x00FF00FF)+(nPos<<8);
		break;
	case IDC_TXT_RED:
		m_clrTxt = (m_clrTxt&0x00FFFF00)+nPos;
		break;
	case IDC_BACK_BLUE:
		m_clrBackGround = (m_clrBackGround&0x0000FFFF)+(nPos<<16);
		break;
	case IDC_BACK_GREEN:
		m_clrBackGround = (m_clrBackGround&0x00FF00FF)+(nPos<<8);
		break;
	case IDC_BACK_RED:
		m_clrBackGround = (m_clrBackGround&0x00FFFF00)+nPos;
		break;
	}

	//�ػ��ı��򴰿�����
	InvalidateRect(&rc);
}
