// PartTransparent.h : main header file for the PARTTRANSPARENT application
//

#if !defined(AFX_PARTTRANSPARENT_H__7FDB632B_E147_4F08_B032_57C068EB2651__INCLUDED_)
#define AFX_PARTTRANSPARENT_H__7FDB632B_E147_4F08_B032_57C068EB2651__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPartTransparentApp:
// See PartTransparent.cpp for the implementation of this class
//

class CPartTransparentApp : public CWinApp
{
public:
	CPartTransparentApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPartTransparentApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CPartTransparentApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARTTRANSPARENT_H__7FDB632B_E147_4F08_B032_57C068EB2651__INCLUDED_)
