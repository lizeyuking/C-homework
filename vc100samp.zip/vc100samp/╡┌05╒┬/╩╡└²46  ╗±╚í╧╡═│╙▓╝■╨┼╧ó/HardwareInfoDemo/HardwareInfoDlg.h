#if !defined(AFX_HARDWAREINFODLG_H__E9471AD5_6390_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_HARDWAREINFODLG_H__E9471AD5_6390_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HardwareInfoDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHardwareInfoDlg dialog

class CHardwareInfoDlg : public CDialog
{
// Construction
public:
	CHardwareInfoDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CHardwareInfoDlg)
	enum { IDD = IDD_DIALOG_HARDWAREINFO };
	CStatic	m_Memory;
	CStatic	m_CpuType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHardwareInfoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHardwareInfoDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HARDWAREINFODLG_H__E9471AD5_6390_11D6_8F32_00E04CE76240__INCLUDED_)
