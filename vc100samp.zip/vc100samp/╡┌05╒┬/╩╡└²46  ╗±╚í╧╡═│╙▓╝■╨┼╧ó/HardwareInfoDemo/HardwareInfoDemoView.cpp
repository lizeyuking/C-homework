// HardwareInfoDemoView.cpp : implementation of the CHardwareInfoDemoView class
//

#include "stdafx.h"
#include "HardwareInfoDemo.h"

#include "HardwareInfoDemoDoc.h"
#include "HardwareInfoDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHardwareInfoDemoView

IMPLEMENT_DYNCREATE(CHardwareInfoDemoView, CView)

BEGIN_MESSAGE_MAP(CHardwareInfoDemoView, CView)
	//{{AFX_MSG_MAP(CHardwareInfoDemoView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHardwareInfoDemoView construction/destruction

CHardwareInfoDemoView::CHardwareInfoDemoView()
{
	// TODO: add construction code here

}

CHardwareInfoDemoView::~CHardwareInfoDemoView()
{
}

BOOL CHardwareInfoDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHardwareInfoDemoView drawing

void CHardwareInfoDemoView::OnDraw(CDC* pDC)
{
	CHardwareInfoDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CHardwareInfoDemoView printing

BOOL CHardwareInfoDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CHardwareInfoDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CHardwareInfoDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CHardwareInfoDemoView diagnostics

#ifdef _DEBUG
void CHardwareInfoDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CHardwareInfoDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CHardwareInfoDemoDoc* CHardwareInfoDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHardwareInfoDemoDoc)));
	return (CHardwareInfoDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHardwareInfoDemoView message handlers
