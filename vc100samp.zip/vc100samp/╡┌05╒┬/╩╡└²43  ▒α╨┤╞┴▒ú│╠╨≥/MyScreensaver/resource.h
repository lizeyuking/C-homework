//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyScreensaver.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MYSCREENSAVER_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_NOCURSOR                    129
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     131
#define IDB_BITMAP3                     132
#define IDB_BITMAP4                     133
#define IDB_BITMAP5                     134
#define IDB_BITMAP55                    139

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
