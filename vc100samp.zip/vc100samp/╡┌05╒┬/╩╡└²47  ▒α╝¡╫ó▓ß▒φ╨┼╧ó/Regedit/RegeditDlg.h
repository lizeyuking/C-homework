// RegeditDlg.h : header file
//

#if !defined(AFX_REGEDITDLG_H__A350F5C9_6AC2_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_REGEDITDLG_H__A350F5C9_6AC2_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CRegeditDlg dialog

class CRegeditDlg : public CDialog
{
// Construction
public:
	CRegeditDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CRegeditDlg)
	enum { IDD = IDD_REGEDIT_DIALOG };
	CString	m_strCompany;
	CString	m_strOwner;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRegeditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	LPBYTE CString_To_LPBYTE(CString str);
	// Generated message map functions
	//{{AFX_MSG(CRegeditDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnQuery();
	afx_msg void OnModify();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REGEDITDLG_H__A350F5C9_6AC2_11D6_8F32_00E04CE76240__INCLUDED_)
