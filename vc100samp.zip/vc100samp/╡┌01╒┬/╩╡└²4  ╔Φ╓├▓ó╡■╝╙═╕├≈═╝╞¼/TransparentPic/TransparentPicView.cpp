// TransparentPicView.cpp : implementation of the CTransparentPicView class
//

#include "stdafx.h"
#include "TransparentPic.h"

#include "TransparentPicDoc.h"
#include "TransparentPicView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicView

IMPLEMENT_DYNCREATE(CTransparentPicView, CView)

BEGIN_MESSAGE_MAP(CTransparentPicView, CView)
	//{{AFX_MSG_MAP(CTransparentPicView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicView construction/destruction

CTransparentPicView::CTransparentPicView()
{
	// TODO: add construction code here

}

CTransparentPicView::~CTransparentPicView()
{
}

BOOL CTransparentPicView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicView drawing

void CTransparentPicView::OnDraw(CDC* pDC)
{
	CTransparentPicDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	//���ײ�λͼ
	CBitmap bmp;
	bmp.LoadBitmap(IDB_BITMAP1);
	BITMAP bm;
	bmp.GetBitmap(&bm);
	int nWidth=bm.bmWidth,nHeight=bm.bmHeight;
	CDC MemDC;
	MemDC.CreateCompatibleDC(pDC);
	CBitmap* pOldBmp = MemDC.SelectObject(&bmp);
	pDC->BitBlt(0,0,nWidth,nHeight,&MemDC,0,0,SRCCOPY);
	MemDC.SelectObject(pOldBmp);
	//���ϲ�͸��λͼ
	DrawTransparent(pDC,0,0,RGB(0,0,0));

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicView printing

BOOL CTransparentPicView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTransparentPicView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTransparentPicView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicView diagnostics

#ifdef _DEBUG
void CTransparentPicView::AssertValid() const
{
	CView::AssertValid();
}

void CTransparentPicView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTransparentPicDoc* CTransparentPicView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTransparentPicDoc)));
	return (CTransparentPicDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicView message handlers

void CTransparentPicView::DrawTransparent(CDC *pDC, int x, int y, COLORREF crColour)
{
	COLORREF crOldBack=pDC->SetBkColor(RGB(255,255,255));
	COLORREF crOldText=pDC->SetTextColor(RGB(0,0,0));
	CDC dcImage, dcMask;
	CBitmap bmp;
	bmp.LoadBitmap(IDB_BITMAP2);
	//IDB_BITMAP1�Ǵ���ʾλͼ����ԴID
	BITMAP bm;bmp.GetBitmap(&bm);
	int nWidth=bm.bmWidth,nHeight=bm.bmHeight;
	//Ϊͼ��mask������һ��DC
	dcImage.CreateCompatibleDC(pDC);
	dcMask.CreateCompatibleDC(pDC);
	//��ͼ��װ��image DC
	CBitmap* pOldBitmapImage=dcImage.SelectObject(&bmp);
	//Ϊ�����롱λͼ����һ����ɫbitmap
	CBitmap bitmapMask;
	bitmapMask.CreateBitmap(nWidth, nHeight, 1, 1, NULL); //��maskλͼװ��mask DC
	CBitmap* pOldBitmapMask = dcMask.SelectObject(&bitmapMask); //��͸��ɫ���������롱λͼ
	dcImage.SetBkColor(crColour);//crColor��λͼ�е�͸��ɫ
	dcMask.BitBlt(0, 0, nWidth, nHeight, &dcImage, 0, 0, SRCCOPY);//��3������ʵ�ʵĻ���
	pDC->BitBlt(x, y, nWidth, nHeight, &dcImage, 0, 0, SRCINVERT);
	pDC->BitBlt(x, y, nWidth, nHeight, &dcMask, 0, 0, SRCAND);
	pDC->BitBlt(x, y, nWidth, nHeight, &dcImage, 0, 0, SRCINVERT); //�ָ�ԭ������
	dcImage.SelectObject(pOldBitmapImage);
	dcMask.SelectObject(pOldBitmapMask);
	pDC->SetBkColor(crOldBack);
	pDC->SetTextColor(crOldText);
}
