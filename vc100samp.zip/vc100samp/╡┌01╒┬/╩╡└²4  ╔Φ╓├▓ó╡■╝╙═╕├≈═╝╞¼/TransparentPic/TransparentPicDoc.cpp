// TransparentPicDoc.cpp : implementation of the CTransparentPicDoc class
//

#include "stdafx.h"
#include "TransparentPic.h"

#include "TransparentPicDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicDoc

IMPLEMENT_DYNCREATE(CTransparentPicDoc, CDocument)

BEGIN_MESSAGE_MAP(CTransparentPicDoc, CDocument)
	//{{AFX_MSG_MAP(CTransparentPicDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicDoc construction/destruction

CTransparentPicDoc::CTransparentPicDoc()
{
	// TODO: add one-time construction code here

}

CTransparentPicDoc::~CTransparentPicDoc()
{
}

BOOL CTransparentPicDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTransparentPicDoc serialization

void CTransparentPicDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicDoc diagnostics

#ifdef _DEBUG
void CTransparentPicDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTransparentPicDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTransparentPicDoc commands
