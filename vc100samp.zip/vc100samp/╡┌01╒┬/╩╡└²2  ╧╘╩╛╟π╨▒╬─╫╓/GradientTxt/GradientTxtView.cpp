// GradientTxtView.cpp : implementation of the CGradientTxtView class
//

#include "stdafx.h"
#include "GradientTxt.h"

#include "GradientTxtDoc.h"
#include "GradientTxtView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtView

IMPLEMENT_DYNCREATE(CGradientTxtView, CView)

BEGIN_MESSAGE_MAP(CGradientTxtView, CView)
	//{{AFX_MSG_MAP(CGradientTxtView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtView construction/destruction

CGradientTxtView::CGradientTxtView()
{
	// TODO: add construction code here

}

CGradientTxtView::~CGradientTxtView()
{
}

BOOL CGradientTxtView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtView drawing

void CGradientTxtView::OnDraw(CDC* pDC)
{
	CGradientTxtDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	//�õ��ͻ����Ĵ�С
	CRect rcClient;
	GetClientRect (rcClient);
	
	//��������ַ���.
	CString str (_T ("oooo������I am rotating!"));
	
	//���͸����ɫ����
	pDC->SetBkMode (TRANSPARENT);
	pDC->SetTextColor (RGB (255,0,0));
	CFont font;
	LOGFONT stFont; //���嶨��ṹ

	//���������ʽ
	memset(&stFont, 0, sizeof(LOGFONT));
	stFont.lfHeight=MulDiv(14, -pDC->GetDeviceCaps(LOGPIXELSY), 72);
	stFont.lfWeight=FW_NORMAL;
	stFont.lfClipPrecision=CLIP_LH_ANGLES;
	strcpy (stFont.lfFaceName, "Arial");
	
	//ÿ��15������ַ���
	for (int nAngle=0; nAngle<3600; nAngle+=150)
	{
		//�趨�µ���ת�Ƕ�
		stFont.lfEscapement=nAngle;
		
		//�������岢ѡ���豸����
		font.CreateFontIndirect(&stFont);
		CFont* pOldFont=pDC ->SelectObject(&font);
		
		//�������
		pDC->TextOut(rcClient.left + rcClient.Width()/2,rcClient.top + rcClient.Height()/2,str);
		
		//ԭ������
		pDC->SelectObject(pOldFont);
		font.DeleteObject();
	}
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtView printing

BOOL CGradientTxtView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CGradientTxtView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CGradientTxtView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtView diagnostics

#ifdef _DEBUG
void CGradientTxtView::AssertValid() const
{
	CView::AssertValid();
}

void CGradientTxtView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGradientTxtDoc* CGradientTxtView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGradientTxtDoc)));
	return (CGradientTxtDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtView message handlers
