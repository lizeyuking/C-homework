// GradientTxtDoc.cpp : implementation of the CGradientTxtDoc class
//

#include "stdafx.h"
#include "GradientTxt.h"

#include "GradientTxtDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtDoc

IMPLEMENT_DYNCREATE(CGradientTxtDoc, CDocument)

BEGIN_MESSAGE_MAP(CGradientTxtDoc, CDocument)
	//{{AFX_MSG_MAP(CGradientTxtDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtDoc construction/destruction

CGradientTxtDoc::CGradientTxtDoc()
{
	// TODO: add one-time construction code here

}

CGradientTxtDoc::~CGradientTxtDoc()
{
}

BOOL CGradientTxtDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CGradientTxtDoc serialization

void CGradientTxtDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtDoc diagnostics

#ifdef _DEBUG
void CGradientTxtDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGradientTxtDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGradientTxtDoc commands
