// TextShadePrjDoc.cpp : implementation of the CTextShadePrjDoc class
//

#include "stdafx.h"
#include "TextShadePrj.h"

#include "TextShadePrjDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc

IMPLEMENT_DYNCREATE(CTextShadePrjDoc, CDocument)

BEGIN_MESSAGE_MAP(CTextShadePrjDoc, CDocument)
	//{{AFX_MSG_MAP(CTextShadePrjDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc construction/destruction

CTextShadePrjDoc::CTextShadePrjDoc()
{
	// TODO: add one-time construction code here

}

CTextShadePrjDoc::~CTextShadePrjDoc()
{
}

BOOL CTextShadePrjDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc serialization

void CTextShadePrjDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc diagnostics

#ifdef _DEBUG
void CTextShadePrjDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTextShadePrjDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc commands
