// TextShadePrjDoc.h : interface of the CTextShadePrjDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTSHADEPRJDOC_H__2D492A41_C6DE_4C22_AF37_FE90186CB28D__INCLUDED_)
#define AFX_TEXTSHADEPRJDOC_H__2D492A41_C6DE_4C22_AF37_FE90186CB28D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTextShadePrjDoc : public CDocument
{
protected: // create from serialization only
	CTextShadePrjDoc();
	DECLARE_DYNCREATE(CTextShadePrjDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTextShadePrjDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTextShadePrjDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTextShadePrjDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXTSHADEPRJDOC_H__2D492A41_C6DE_4C22_AF37_FE90186CB28D__INCLUDED_)
