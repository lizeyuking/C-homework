// TextShadePrjView.cpp : implementation of the CTextShadePrjView class
//

#include "stdafx.h"
#include "TextShadePrj.h"

#include "TextShadePrjDoc.h"
#include "TextShadePrjView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjView

IMPLEMENT_DYNCREATE(CTextShadePrjView, CView)

BEGIN_MESSAGE_MAP(CTextShadePrjView, CView)
	//{{AFX_MSG_MAP(CTextShadePrjView)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjView construction/destruction

CTextShadePrjView::CTextShadePrjView()
{
	// TODO: add construction code here
	m_nRed = m_nGreen = m_nBlue = 0;
	
}

CTextShadePrjView::~CTextShadePrjView()
{
	
}

BOOL CTextShadePrjView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjView drawing

void CTextShadePrjView::OnDraw(CDC* pDC)
{
	CTextShadePrjDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	//��������ַ���.
	CString str (_T ("Hello������I am Shading!"));
	//����������ɫ
	pDC->SetTextColor (RGB (m_nRed,m_nGreen,m_nBlue));

	//�������
	pDC->TextOut(100,100,str);
}

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjView printing

BOOL CTextShadePrjView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTextShadePrjView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTextShadePrjView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjView diagnostics

#ifdef _DEBUG
void CTextShadePrjView::AssertValid() const
{
	CView::AssertValid();
}

void CTextShadePrjView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTextShadePrjDoc* CTextShadePrjView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTextShadePrjDoc)));
	return (CTextShadePrjDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjView message handlers

void CTextShadePrjView::OnTimer(UINT nIDEvent) 
{
	CView::OnTimer(nIDEvent);
	
	//�ı����ֵ�rgbֵ
	if(m_nRed<=205)
		m_nRed += 50;
	else if(m_nRed == 255)
		m_nRed = 0; 
	else
		m_nRed = 255;

	if(m_nGreen<=205)
		m_nGreen += 50;
	else if(m_nRed == 255)
		m_nGreen = 0; 
	else
		m_nGreen = 255;

	if(m_nBlue<=205)
		m_nBlue += 50;
	else if(m_nBlue == 255)
		m_nBlue = 0; 
	else
		m_nBlue = 255;
	
	//�ػ�����
	Invalidate();
}

void CTextShadePrjView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	//������ʱ��
	SetTimer(0,1000,NULL);
}

void CTextShadePrjView::OnDestroy() 
{
	//�رն�ʱ��
	KillTimer(0);

	CView::OnDestroy();
}
