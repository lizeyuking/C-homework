// TextShadePrjView.h : interface of the CTextShadePrjView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTSHADEPRJVIEW_H__13EE3B40_F93F_435F_86F8_F459ACC56949__INCLUDED_)
#define AFX_TEXTSHADEPRJVIEW_H__13EE3B40_F93F_435F_86F8_F459ACC56949__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTextShadePrjView : public CView
{
protected: // create from serialization only
	CTextShadePrjView();
	DECLARE_DYNCREATE(CTextShadePrjView)

// Attributes
public:
	CTextShadePrjDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTextShadePrjView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTextShadePrjView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	int m_nBlue;
	int m_nGreen;
	int m_nRed;
	//{{AFX_MSG(CTextShadePrjView)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TextShadePrjView.cpp
inline CTextShadePrjDoc* CTextShadePrjView::GetDocument()
   { return (CTextShadePrjDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXTSHADEPRJVIEW_H__13EE3B40_F93F_435F_86F8_F459ACC56949__INCLUDED_)
