#if !defined(AFX_MEMDC_H__CA1D3541_7235_11D1_ABBA_00A0243D1382__INCLUDED_)
#define AFX_MEMDC_H__CA1D3541_7235_11D1_ABBA_00A0243D1382__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MemDC.h : header file


class CMemDC : public CDC
{
public:
	
	//�����ڴ��豸����
	CMemDC(CDC* pDC) : CDC()
    {
		ASSERT(pDC != NULL);
		
		m_pDC = pDC;
		m_pOldBitmap = NULL;
        m_bMemDC = !pDC->IsPrinting();
		
        if (m_bMemDC)
		{
            pDC->GetClipBox(&m_rect);
            CreateCompatibleDC(pDC);
            m_bitmap.CreateCompatibleBitmap(pDC, m_rect.Width(), m_rect.Height());
			m_pOldBitmap = SelectObject(&m_bitmap);
            SetWindowOrg(m_rect.left, m_rect.top);
        }
		else	
		{
            m_bPrinting = pDC->m_bPrinting;
            m_hDC		= pDC->m_hDC;
            m_hAttribDC = pDC->m_hAttribDC;
        }
	}
	
	//����
	~CMemDC()
    {
		if (m_bMemDC) {	
			m_pDC->BitBlt(m_rect.left, m_rect.top, m_rect.Width(), m_rect.Height(),
				this, m_rect.left, m_rect.top, SRCCOPY);
			
            SelectObject(m_pOldBitmap);
		} else {
            m_hDC = m_hAttribDC = NULL;
		}
	}
	
    CMemDC* operator->() {return this;}
	
    operator CMemDC*() {return this;}

private:
	CBitmap  m_bitmap;		
    CBitmap* m_pOldBitmap;	
    CDC*     m_pDC;		
    CRect    m_rect;		
    BOOL     m_bMemDC;		
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MEMDC_H__CA1D3541_7235_11D1_ABBA_00A0243D1382__INCLUDED_)
