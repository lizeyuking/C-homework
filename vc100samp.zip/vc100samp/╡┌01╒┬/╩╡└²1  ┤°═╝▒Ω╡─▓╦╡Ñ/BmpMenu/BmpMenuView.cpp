// BmpMenuView.cpp : implementation of the CBmpMenuView class
//

#include "stdafx.h"
#include "BmpMenu.h"

#include "BmpMenuDoc.h"
#include "BmpMenuView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuView

IMPLEMENT_DYNCREATE(CBmpMenuView, CView)

BEGIN_MESSAGE_MAP(CBmpMenuView, CView)
	//{{AFX_MSG_MAP(CBmpMenuView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuView construction/destruction

CBmpMenuView::CBmpMenuView()
{
	// TODO: add construction code here

}

CBmpMenuView::~CBmpMenuView()
{
}

BOOL CBmpMenuView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuView drawing

void CBmpMenuView::OnDraw(CDC* pDC)
{
	CBmpMenuDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuView printing

BOOL CBmpMenuView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CBmpMenuView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CBmpMenuView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuView diagnostics

#ifdef _DEBUG
void CBmpMenuView::AssertValid() const
{
	CView::AssertValid();
}

void CBmpMenuView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CBmpMenuDoc* CBmpMenuView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBmpMenuDoc)));
	return (CBmpMenuDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuView message handlers
