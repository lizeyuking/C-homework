// BmpMenuDoc.cpp : implementation of the CBmpMenuDoc class
//

#include "stdafx.h"
#include "BmpMenu.h"

#include "BmpMenuDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuDoc

IMPLEMENT_DYNCREATE(CBmpMenuDoc, CDocument)

BEGIN_MESSAGE_MAP(CBmpMenuDoc, CDocument)
	//{{AFX_MSG_MAP(CBmpMenuDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuDoc construction/destruction

CBmpMenuDoc::CBmpMenuDoc()
{
	// TODO: add one-time construction code here

}

CBmpMenuDoc::~CBmpMenuDoc()
{
}

BOOL CBmpMenuDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CBmpMenuDoc serialization

void CBmpMenuDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuDoc diagnostics

#ifdef _DEBUG
void CBmpMenuDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CBmpMenuDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBmpMenuDoc commands
