// MyCDPlayerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyCDPlayer.h"
#include "MyCDPlayerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyCDPlayerDlg dialog

CMyCDPlayerDlg::CMyCDPlayerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyCDPlayerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyCDPlayerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyCDPlayerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyCDPlayerDlg)
	DDX_Control(pDX, IDC_MUSIC_LIST, m_lstMusics);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyCDPlayerDlg, CDialog)
	//{{AFX_MSG_MAP(CMyCDPlayerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_PLAY, OnPlay)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_BN_CLICKED(IDC_PAUSE, OnPause)
	ON_BN_CLICKED(IDC_FORWARD, OnForward)
	ON_BN_CLICKED(IDC_BACK, OnBack)
	ON_BN_CLICKED(IDC_SKIPBACK, OnSkipback)
	ON_BN_CLICKED(IDC_SKIPFORWARD, OnSkipforward)
	ON_CBN_SELCHANGE(IDC_MUSIC_LIST, OnSelchangeMusicList)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyCDPlayerDlg message handlers

BOOL CMyCDPlayerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	//���豸
	m_CDAudio.Open();
	//����һ����ʱ��
	SetTimer( 1, 1000, NULL );
	//����Ŀ�ӵ�CComboBox�ؼ���
	for(int i=0;i<m_CDAudio.GetTotalTracks();i++)
	{
		CString str;
		str.Format("��Ŀ%d",i+1);
		m_lstMusics.AddString(str);
	}
	m_lstMusics.SetCurSel(0);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyCDPlayerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyCDPlayerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyCDPlayerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
void CMyCDPlayerDlg::OnDestroy() 
{
	//ɱ����ʱ��
	KillTimer(1);
	CDialog::OnDestroy();	
}
void CMyCDPlayerDlg::OnTimer(UINT nIDEvent) 
{	
	BOOL bDriveReady = TRUE;

	//��õ�ǰ��Ŀ�Ѿ����ŵ�ʱ�䣬����ʾ
	CString strStatus;
	strStatus.Format( "[%d] %02d:%02d",
		m_CDAudio.GetCurrentTrack(),
		m_CDAudio.GetMinutes(),
		m_CDAudio.GetSeconds() );

	//û��CD
	if( m_CDAudio.GetCurrentTrack() == -1 ){
		strStatus = "û��CD";
		bDriveReady = FALSE;
		}
	SetDlgItemText( IDC_TRACKINFO, strStatus );

	//���CD���ܹ����ȣ�����ʾ
	CString strLength;
	int nMinutes, nSeconds;
	m_CDAudio.GetTotalLength( &nMinutes,
		&nSeconds );
	strLength.Format( "�ܹ�����(m:s): %02d:%02d",
		nMinutes, nSeconds );
	if( nMinutes == -1 )
		strLength = "�ܹ�����(m:s): 00:00";
	SetDlgItemText( IDC_TOTALTIME, strLength );

	//��õ�ǰ����Ŀ���ȣ�����ʾ
	m_CDAudio.GetTrackLength(
		m_CDAudio.GetCurrentTrack(),
		&nMinutes, &nSeconds );
	strLength.Format( "��Ŀ����(m:s): %02d:%02d",
		nMinutes, nSeconds );
	if( nMinutes == -1 )
		strLength = "��Ŀ����(m:s): 00:00";
	SetDlgItemText( IDC_TRACKTIME, strLength );

	//���ݲ���״̬�ı䰴ť�Ŀ����벻����״̬
	CWnd *pWnd;
	pWnd = GetDlgItem( IDC_BACK );
	pWnd->EnableWindow( bDriveReady );
	pWnd = GetDlgItem( IDC_FORWARD );
	pWnd->EnableWindow( bDriveReady );
	pWnd = GetDlgItem( IDC_SKIPBACK );
	pWnd->EnableWindow( bDriveReady );
	pWnd = GetDlgItem( IDC_SKIPFORWARD );
	pWnd->EnableWindow( bDriveReady );

	BOOL bPaused;
	if( m_CDAudio.IsPlaying( &bPaused ) ){
		pWnd = GetDlgItem( IDC_PLAY );
		pWnd->EnableWindow( bPaused );
		pWnd = GetDlgItem( IDC_STOP );
		pWnd->EnableWindow( bDriveReady );
		pWnd = GetDlgItem( IDC_PAUSE );
		pWnd->EnableWindow( bDriveReady && !bPaused );
		}
	else{
		pWnd = GetDlgItem( IDC_PLAY );
		pWnd->EnableWindow( bDriveReady );
		pWnd = GetDlgItem( IDC_STOP );
		pWnd->EnableWindow( FALSE );
		pWnd = GetDlgItem( IDC_PAUSE );
		pWnd->EnableWindow( FALSE );
		}

	CDialog::OnTimer(nIDEvent);
}

void CMyCDPlayerDlg::OnPlay() 
{
	// ��������е�CD�Ѿ�׼���þͲ���
	if( m_CDAudio.IsDriveReady() )
		m_CDAudio.Play();
}

void CMyCDPlayerDlg::OnStop() 
{
	// ֹͣ����
	m_CDAudio.Stop();
}

void CMyCDPlayerDlg::OnPause() 
{
	// ��ͣ����
	m_CDAudio.Pause();
}

void CMyCDPlayerDlg::OnForward() 
{
	
	// ��õ�ǰ��Ŀ�Ĳ��ų���
	int nMinutes = m_CDAudio.GetMinutes();
	int nSeconds = m_CDAudio.GetSeconds();
	int nTrack = m_CDAudio.GetCurrentTrack();

	if( nMinutes == -1 )
		return;

	//��ǰ��Ծ5�룬��֤û�г���
	nSeconds += 5;
	if( nSeconds > 59 ){
		nMinutes++;
		nSeconds -= 60;
		}

	int nTrackMinutes, nTrackSeconds;
	m_CDAudio.GetTrackLength( nTrack,
		&nTrackMinutes, &nTrackSeconds );

	if( nMinutes * 60 + nSeconds >
		nTrackMinutes * 60 + nTrackSeconds ){
		nMinutes = nTrackMinutes;
		nSeconds = nTrackSeconds;
		}

	//��λ���µ�λ��
	m_CDAudio.SeekTo( nTrack,
		nMinutes, nSeconds, 0 );
}

void CMyCDPlayerDlg::OnBack() 
{
	// ��õ�ǰ��Ŀ�Ĳ��ų���
	int nMinutes = m_CDAudio.GetMinutes();
	int nSeconds = m_CDAudio.GetSeconds();
	int nTrack = m_CDAudio.GetCurrentTrack();

	if( nMinutes == -1 )
		return;

	//��ǰ��Ծ5�룬��֤û�г���
	nSeconds -= 5;
	if( nSeconds < 0 ){
		nMinutes--;
		nSeconds += 60;
		if( nMinutes < 0 )
			nMinutes = 0;
		}

	//��λ���µ�λ��
	m_CDAudio.SeekTo( nTrack,
		nMinutes, nSeconds, 0 );
}

void CMyCDPlayerDlg::OnSkipback() 
{
	//�����Ծһ����Ŀ
	int nTrack = m_CDAudio.GetCurrentTrack() - 1;

	if( nTrack < 1 )
		nTrack = m_CDAudio.GetTotalTracks();

	m_CDAudio.SeekTo( nTrack, 0, 0, 0 );
}

void CMyCDPlayerDlg::OnSkipforward() 
{
	//��ǰ��Ծһ����Ŀ
	int nTrack = m_CDAudio.GetCurrentTrack() + 1;

	if( nTrack > m_CDAudio.GetTotalTracks() )
		nTrack = 1;

	m_CDAudio.SeekTo( nTrack, 0, 0, 0 );
}

void CMyCDPlayerDlg::OnSelchangeMusicList() 
{
	//��CComboBox����Ŀѡ��ı�ʱ�����ű�ѡ����Ŀ
	int nSelTrack = m_lstMusics.GetCurSel();
	m_CDAudio.SeekTo(nSelTrack+1,0,0,0);
}


