// DSDemoDlg.h : header file
//

#if !defined(AFX_DSDEMODLG_H__5E7329CD_AB39_4CF3_8AC9_9A2480FCE9D3__INCLUDED_)
#define AFX_DSDEMODLG_H__5E7329CD_AB39_4CF3_8AC9_9A2480FCE9D3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDSDemoDlg dialog
#include "DSBuffer.h"

class CDSDemoDlg : public CDialog
{
// Construction
public:
	CDSDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDSDemoDlg)
	enum { IDD = IDD_DSDEMO_DIALOG };
	CSliderCtrl	m_SliderEffectVolume;
	CSliderCtrl	m_SliderBKVolume;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDSDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDSDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnReleasedcaptureBkvolume(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureEffectvolume(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEffect();
	afx_msg void OnPlaybkmusic();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	BOOL InitializeDirectSound(HWND hWnd); //��ʼ������
	void ClearDSBuffer();     //����������

public:
	LPDIRECTSOUND	m_lpDS;		        //DirectSound����
	CDSBuffer* m_lpBkGrdDSBuffer;       //�������ֻ���������       
	CDSBuffer* m_lpYinXiaoDSBuffer;     //��Ч����������
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSDEMODLG_H__5E7329CD_AB39_4CF3_8AC9_9A2480FCE9D3__INCLUDED_)
