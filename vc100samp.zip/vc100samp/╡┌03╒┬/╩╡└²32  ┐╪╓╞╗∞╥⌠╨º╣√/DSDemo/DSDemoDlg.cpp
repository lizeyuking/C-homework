// DSDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DSDemo.h"
#include "DSDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDSDemoDlg dialog

CDSDemoDlg::CDSDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDSDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDSDemoDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDSDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDSDemoDlg)
	DDX_Control(pDX, ID_EFFECTVOLUME, m_SliderEffectVolume);
	DDX_Control(pDX, ID_BKVOLUME, m_SliderBKVolume);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDSDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CDSDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(NM_RELEASEDCAPTURE, ID_BKVOLUME, OnReleasedcaptureBkvolume)
	ON_NOTIFY(NM_RELEASEDCAPTURE, ID_EFFECTVOLUME, OnReleasedcaptureEffectvolume)
	ON_BN_CLICKED(IDC_EFFECT, OnEffect)
	ON_BN_CLICKED(IDC_PLAYBKMUSIC, OnPlaybkmusic)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDSDemoDlg message handlers

BOOL CDSDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//����������Χ
	m_SliderBKVolume.SetRange(0,100);
	m_SliderEffectVolume.SetRange(0,100);
	//��ʼʱ��������������ֵ
	m_SliderBKVolume.SetPos(100);
	m_SliderEffectVolume.SetPos(100);
	//ѡ�в��ű������ָ�ѡ��
	((CButton*)GetDlgItem(IDC_PLAYBKMUSIC))->SetCheck(1);  

	//��ʼ��DirectSound����
	if(!InitializeDirectSound(*AfxGetMainWnd()))
	{
		AfxMessageBox("��ʼ��DirectSoundʧ��!",MB_OK);
		CDialog::OnOK();
		return TRUE  ;
	}
	//��������������
	m_lpBkGrdDSBuffer=new CDSBuffer("bk.wav",TRUE,m_lpDS);
    m_lpYinXiaoDSBuffer=new CDSBuffer("effect.wav",FALSE,m_lpDS);
	//���ű�������
	m_lpBkGrdDSBuffer->PlaySound();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDSDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDSDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDSDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CDSDemoDlg::InitializeDirectSound(HWND hWnd)
{
	// �����������ֺ���ЧDirectSound����
	if (DS_OK != DirectSoundCreate(NULL, &m_lpDS, NULL))
	{
		::MessageBox(NULL,"����DirectSound����ʧ��\n�Ҳ��������õ������豸",NULL,MB_OK);
		return FALSE;
	}

	// ����Э������
	if (DS_OK != m_lpDS->SetCooperativeLevel(hWnd, DSSCL_NORMAL))
	{
		::MessageBox(NULL,"����Э������ʧ��",NULL,MB_OK);
		return FALSE;
	}

	return TRUE;
}

void CDSDemoDlg::ClearDSBuffer()
{
    m_lpBkGrdDSBuffer->StopSound();
	m_lpYinXiaoDSBuffer->StopSound();
	if (m_lpBkGrdDSBuffer)
		delete m_lpBkGrdDSBuffer;
	if (m_lpYinXiaoDSBuffer)
		delete m_lpYinXiaoDSBuffer;
}

void CDSDemoDlg::OnReleasedcaptureBkvolume(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int nPos = m_SliderBKVolume.GetPos();
	m_lpBkGrdDSBuffer->SetVolume(nPos);
	
	*pResult = 0;
}

void CDSDemoDlg::OnReleasedcaptureEffectvolume(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int nPos = m_SliderEffectVolume.GetPos();
	m_lpYinXiaoDSBuffer->SetVolume(nPos);

	*pResult = 0;
}

void CDSDemoDlg::OnEffect() 
{
	m_lpYinXiaoDSBuffer->PlaySound();
	
}

void CDSDemoDlg::OnPlaybkmusic() 
{
	CButton* pButton = (CButton*)GetDlgItem(IDC_PLAYBKMUSIC);
	BOOL bFlag = (pButton->GetCheck() == 1);
	if (bFlag)	m_lpBkGrdDSBuffer->PlaySound();
	else m_lpBkGrdDSBuffer->StopSound();
}


void CDSDemoDlg::OnClose() 
{
	// ɾ����������������
	ClearDSBuffer();
	CDialog::OnClose();
}
