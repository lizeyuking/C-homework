//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PlayWave.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_PLAYWATYPE                  129
#define ID_SND                          32771
#define ID_PLAY                         32771
#define ID_MCI                          32772
#define ID_OPEN                         32773
#define ID_STOP                         32774
#define ID_EXIT                         32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
