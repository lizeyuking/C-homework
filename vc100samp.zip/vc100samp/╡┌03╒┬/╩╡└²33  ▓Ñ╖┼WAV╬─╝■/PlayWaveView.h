// PlayWaveView.h : interface of the CPlayWaveView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLAYWAVEVIEW_H__10430C21_918E_11D4_8B3A_0050BAD195A9__INCLUDED_)
#define AFX_PLAYWAVEVIEW_H__10430C21_918E_11D4_8B3A_0050BAD195A9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPlayWaveView : public CView
{
protected: // create from serialization only
	CPlayWaveView();
	DECLARE_DYNCREATE(CPlayWaveView)

// Attributes
public:
	CPlayWaveDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlayWaveView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPlayWaveView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPlayWaveView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in PlayWaveView.cpp
inline CPlayWaveDoc* CPlayWaveView::GetDocument()
   { return (CPlayWaveDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAYWAVEVIEW_H__10430C21_918E_11D4_8B3A_0050BAD195A9__INCLUDED_)
