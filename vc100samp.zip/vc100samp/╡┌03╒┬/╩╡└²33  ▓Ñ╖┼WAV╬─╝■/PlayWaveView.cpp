// PlayWaveView.cpp : implementation of the CPlayWaveView class
//

#include "stdafx.h"
#include "PlayWave.h"

#include "PlayWaveDoc.h"
#include "PlayWaveView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPlayWaveView

IMPLEMENT_DYNCREATE(CPlayWaveView, CView)

BEGIN_MESSAGE_MAP(CPlayWaveView, CView)
	//{{AFX_MSG_MAP(CPlayWaveView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlayWaveView construction/destruction

CPlayWaveView::CPlayWaveView()
{
	// TODO: add construction code here

}

CPlayWaveView::~CPlayWaveView()
{
}

BOOL CPlayWaveView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPlayWaveView drawing

void CPlayWaveView::OnDraw(CDC* pDC)
{
	CPlayWaveDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CPlayWaveView diagnostics

#ifdef _DEBUG
void CPlayWaveView::AssertValid() const
{
	CView::AssertValid();
}

void CPlayWaveView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPlayWaveDoc* CPlayWaveView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPlayWaveDoc)));
	return (CPlayWaveDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPlayWaveView message handlers
