//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VCDPlayer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_VCDPLAYER_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDR_MENU_MAIN                   130
#define IDC_ACTIVEMOVIECONTROL          1000
#define IDC_OPEN                        32771
#define IDC_EXIT                        32772
#define IDC_FULLSCREEN                  32773
#define IDC_ADD_VOLUME                  32774
#define IDC_REDUCE_VOLUME               32775
#define IDC_NO_VOLUME                   32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
