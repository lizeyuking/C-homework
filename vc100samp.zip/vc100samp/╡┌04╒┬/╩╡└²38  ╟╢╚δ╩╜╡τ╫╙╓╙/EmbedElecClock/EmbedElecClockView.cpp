// EmbedElecClockView.cpp : implementation of the CEmbedElecClockView class
//

#include "stdafx.h"
#include "EmbedElecClock.h"

#include "EmbedElecClockDoc.h"
#include "EmbedElecClockView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockView

IMPLEMENT_DYNCREATE(CEmbedElecClockView, CView)

BEGIN_MESSAGE_MAP(CEmbedElecClockView, CView)
	//{{AFX_MSG_MAP(CEmbedElecClockView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockView construction/destruction

CEmbedElecClockView::CEmbedElecClockView()
{
	// TODO: add construction code here

}

CEmbedElecClockView::~CEmbedElecClockView()
{
}

BOOL CEmbedElecClockView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockView drawing

void CEmbedElecClockView::OnDraw(CDC* pDC)
{
	CEmbedElecClockDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockView printing

BOOL CEmbedElecClockView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CEmbedElecClockView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CEmbedElecClockView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockView diagnostics

#ifdef _DEBUG
void CEmbedElecClockView::AssertValid() const
{
	CView::AssertValid();
}

void CEmbedElecClockView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CEmbedElecClockDoc* CEmbedElecClockView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEmbedElecClockDoc)));
	return (CEmbedElecClockDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockView message handlers
