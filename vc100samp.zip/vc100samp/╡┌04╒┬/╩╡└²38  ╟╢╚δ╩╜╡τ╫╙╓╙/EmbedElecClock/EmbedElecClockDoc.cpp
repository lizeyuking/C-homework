// EmbedElecClockDoc.cpp : implementation of the CEmbedElecClockDoc class
//

#include "stdafx.h"
#include "EmbedElecClock.h"

#include "EmbedElecClockDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockDoc

IMPLEMENT_DYNCREATE(CEmbedElecClockDoc, CDocument)

BEGIN_MESSAGE_MAP(CEmbedElecClockDoc, CDocument)
	//{{AFX_MSG_MAP(CEmbedElecClockDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockDoc construction/destruction

CEmbedElecClockDoc::CEmbedElecClockDoc()
{
	// TODO: add one-time construction code here

}

CEmbedElecClockDoc::~CEmbedElecClockDoc()
{
}

BOOL CEmbedElecClockDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockDoc serialization

void CEmbedElecClockDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockDoc diagnostics

#ifdef _DEBUG
void CEmbedElecClockDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEmbedElecClockDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEmbedElecClockDoc commands
