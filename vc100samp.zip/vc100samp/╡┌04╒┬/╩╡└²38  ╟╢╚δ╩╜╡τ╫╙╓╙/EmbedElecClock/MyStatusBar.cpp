// MyStatusBar.cpp: implementation of the CMyStatusBar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MyStatusBar.h"
#include "Resource.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMyStatusBar, CStatusBar)

BEGIN_MESSAGE_MAP(CMyStatusBar, CStatusBar)
ON_WM_CREATE()
ON_WM_DESTROY()
ON_UPDATE_COMMAND_UI(ID_INDICATOR_TIME, OnUpdateIndicatorTime)
END_MESSAGE_MAP()

CMyStatusBar::CMyStatusBar()
: CStatusBar()
, m_strClockFormat("%H:%M:%S")//��ʽ����ʾʱ��ĸ�ʽ
{
}

CMyStatusBar::~CMyStatusBar() {

}
void CMyStatusBar::SetClockFormat(LPCTSTR strClockFormat) 
{
     m_strClockFormat = strClockFormat;
}

//��������
int CMyStatusBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
     CStatusBar::OnCreate(lpCreateStruct);
	 // ��֤ÿ��һ��ʱ�ӻ���£�����һ����ʱ��
     SetTimer(ID_INDICATOR_TIME,1000,NULL);
     return 0;
}

//����ʱ��
void CMyStatusBar::OnUpdateIndicatorTime(CCmdUI* pCmdUI) {
     pCmdUI->Enable(true);
     pCmdUI->SetText(CTime::GetCurrentTime().Format(m_strClockFormat));
}

//�˳�����
void CMyStatusBar::OnDestroy()
{
	//ɱ��Timer
     KillTimer(ID_INDICATOR_TIME);
     CStatusBar::OnDestroy();
}

