// MyStatusBar.h: interface for the CMyStatusBar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYSTATUSBAR_H__1D524155_62DE_11D6_8F32_00E04CE76240__INCLUDED_)
#define AFX_MYSTATUSBAR_H__1D524155_62DE_11D6_8F32_00E04CE76240__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//��������Ӵ����ID,����ֵΪ����һ������ID��һ
#define ID_INDICATOR_TIME ID_INDICATOR_SCRL+1	

class CMyStatusBar : public CStatusBar {
     DECLARE_DYNCREATE(CMyStatusBar)
public:
     CMyStatusBar();
     ~CMyStatusBar();
private:
     CString m_strClockFormat;				//ʱ����ʾʱ��ĸ�ʽ
public:
     void SetClockFormat(LPCTSTR strClockFormat);
     // Overrides
     // ClassWizard generated virtual function overrides
     //{{AFX_VIRTUAL(CMyStatusBar)
     //}}AFX_VIRTUAL
     // Generated message map functions
     //{{AFX_MSG(CMyStatusBar)
     afx_msg void OnDestroy();
     afx_msg void OnUpdateIndicatorTime(CCmdUI* pCmdUI);
     afx_msg int OnCreate( LPCREATESTRUCT lpCreateStruct );
     //}}AFX_MSG
     DECLARE_MESSAGE_MAP()
};



#endif // !defined(AFX_MYSTATUSBAR_H__1D524155_62DE_11D6_8F32_00E04CE76240__INCLUDED_)
