// ClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "ClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientDlg dialog

CClientDlg::CClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClientDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_hSocket = NULL;
}

void CClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientDlg)
	DDX_Control(pDX, ID_SERVER, m_ctrlServer);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClientDlg, CDialog)
	//{{AFX_MSG_MAP(CClientDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SYNCH, OnSynch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientDlg message handlers

BOOL CClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CClientDlg::OnSynch() 
{
	//�õ�������IP��ַ
	BYTE b1,b2,b3,b4;
	m_ctrlServer.GetAddress(b1,b2,b3,b4);
    char strServer[256];
	memset(strServer,0,256);
	sprintf(strServer,"%d.%d.%d.%d",b1,b2,b3,b4);

	//���ÿͻ���Ҫͬ���ķ�������sockaddr_in�ṹ
	m_ServerAddr.sin_family = AF_INET;
	m_ServerAddr.sin_port = htons(CONNECE_PORT);
    m_ServerAddr.sin_addr.s_addr = inet_addr(strServer); 
	
	m_hSocket = NULL;
	//���ӷ�����
	ContactServer();
	
}

void CClientDlg::ContactServer()
{
	ASSERT(m_hSocket == NULL);
	WORD wVersionRequested;
	WSADATA wsaData;
	int nErr;
	wVersionRequested = MAKEWORD( 2, 0 );
	//���������Winsock dll�汾
	nErr = WSAStartup( wVersionRequested, &wsaData );
	if(nErr)
	{
		AfxMessageBox("����Winsock DLL ����");
		return;
	}
	if((m_hSocket = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) 
	{
		AfxMessageBox("����Socketʧ��");
		return;
	}
	
	//���ӷ�����
	ASSERT(m_hSocket != NULL);
	if(connect(m_hSocket, (sockaddr*)&m_ServerAddr, sizeof(SOCKADDR)) == SOCKET_ERROR)
	{
		AfxMessageBox("���ӷ�����ʧ��");
		return;
	}

	//������Ϣ������˴�����Ϣ����Ƚϼ򵥣�
	//ֻ��Get Time�˸��ַ�
	CString strMsg = "Get Time";
	int nLen = strMsg.GetLength();

	//��������˷�����Ϣ����
	FD_SET fd = {1, m_hSocket};
	TIMEVAL tv = {TIME_OUT,0};
	if(select(0, NULL, &fd, NULL, &tv) == 0) 
	{
		AfxMessageBox("���ͳ�ʱ");
		return;
	}
	int nBytesSent;
	if((nBytesSent = send(m_hSocket, strMsg, nLen, 0)) == SOCKET_ERROR) 
	{
		AfxMessageBox("��������ʧ��");
		return;
	}

	if (nBytesSent == nLen)          // ���ͳɹ�
	{
		//��ȡ����
		char m_pReadBuf[256];
		//ѭ���ȴ�����������Ӧ��Ϣ
		while(1)
		{
			//���������ݻ���������
			memset(m_pReadBuf,0,256);
			if(select(0, &fd, NULL, NULL, &tv) == 0) 
			{
				AfxMessageBox("���ܳ�ʱ");
				return;
			}
			//��������
			int nBytesReceived;
			if((nBytesReceived = recv(m_hSocket, m_pReadBuf, 255, 0)) == SOCKET_ERROR)
			{
				AfxMessageBox("��������ʧ��");
				return;
			}
            
			//������ܵ������ݳ��ȴ���0�����˳�ѭ��������ѭ���ȴ�
			if (nBytesReceived > 0)
				break;
		};

		char strCommand[9];
		memset(strCommand,0,9);
		strncpy(strCommand,m_pReadBuf,8);
		if (strcmp(strCommand,"Set Time") == 0)
		{      
			char sYear[5],sMonth[3],sDay[3],sHour[3],sMinute[3],sSecond[3];
			memset(sYear,0,5);
			memset(sMonth,0,3);
			memset(sDay,0,3);
			memset(sHour,0,3);
			memset(sMinute,0,3);
			memset(sSecond,0,3);
		
			//�������������ݸ�ʽ�����н�����ʱ������
			strncpy(sYear,m_pReadBuf+8,4);
			strncpy(sMonth,m_pReadBuf+12,2);
			strncpy(sDay,m_pReadBuf+14,2);
			strncpy(sHour,m_pReadBuf+16,2);
			strncpy(sMinute,m_pReadBuf+18,2);
			strncpy(sSecond,m_pReadBuf+20,2);

			//���ݷ�������������ʱ���������ñ���ʱ��
			SYSTEMTIME time;
			time.wYear = atoi(sYear);
			time.wMonth = atoi(sMonth);
			time.wDay = atoi(sDay);
			time.wHour = atoi(sHour);
			time.wMinute = atoi(sMinute);
			time.wSecond = atoi(sSecond);
			time.wMilliseconds = 0;
			time.wDayOfWeek = 0;           
						
			SetLocalTime(&time);
		}			
	}

	// �ر�Socket
	if(closesocket(m_hSocket) == SOCKET_ERROR)
	{
		AfxMessageBox("�ر�����ʧ��");
		m_hSocket = NULL;
		return;
	}
	
}


