// ServerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Server.h"
#include "ServerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

SOCKET g_hSocket = NULL;


UINT ServerThreadProc(LPVOID pParam)
{
	sockaddr_in saClient;
	SOCKET sockTemp = NULL;

	ASSERT(g_hSocket != NULL);
	int nLengthAddr = sizeof(SOCKADDR);
	//�ɹ����Ӻ󷵻�ʵ�����ӵ�SOCKET���
	sockTemp = accept(g_hSocket, (sockaddr*)&saClient, &nLengthAddr);
	if(sockTemp == INVALID_SOCKET )
	{
		if(WSAGetLastError() != WSAEINTR)
		{
			AfxMessageBox("����Accept����ʧ��");
		}
		return 1;
	}

	// �����˿ͻ��˵������������������һ�߳����¿�ʼ����
	AfxBeginThread(ServerThreadProc,pParam);	
	char sCommand[256];
	memset(sCommand,0,256);

	int nBytesReceived;
	if((nBytesReceived = recv(sockTemp, sCommand, 255, 0)) == SOCKET_ERROR)
	{
		AfxMessageBox("��������ʧ��");
		return 1 ;
	}
	
	if (nBytesReceived == 0) return 1;

	//�����Ƿ���Ŀ�����
    if (strcmp(sCommand,"Get Time") == 0)
	{
		char sBuff[256];
		memset(sBuff,0,256);

		//��ȡ��������ǰʱ��
		SYSTEMTIME time;
		GetLocalTime(&time);

		sprintf(sBuff,"Set Time%4d%2d%2d%2d%2d%2d",
				time.wYear,time.wMonth,time.wDay,
				time.wHour,time.wMinute,time.wSecond);                

		//��������
		int nBytesSent;
		if((nBytesSent = send(sockTemp, sBuff, strlen(sBuff), 0)) == SOCKET_ERROR) 
		{
			AfxMessageBox("��������ʧ��");
			return 1;
		}
	}

	// �ر�Socket
	if(closesocket(sockTemp) == SOCKET_ERROR)
	{
		AfxMessageBox("�ر�����ʧ��");
		sockTemp = NULL;
		return 1;
	}
	

	return 0;
}
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerDlg dialog

CServerDlg::CServerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CServerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CServerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CServerDlg, CDialog)
	//{{AFX_MSG_MAP(CServerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_END, OnEnd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerDlg message handlers

BOOL CServerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CServerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CServerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CServerDlg::OnStart() 
{
	sockaddr_in saServer;
	saServer.sin_family = AF_INET;
	saServer.sin_port = htons(CONNECE_PORT);
	saServer.sin_addr.s_addr = htonl(INADDR_ANY); 
	
    ASSERT(g_hSocket == NULL);
	WORD wVersionRequested;
	WSADATA wsaData;
	int nErr;
	wVersionRequested = MAKEWORD( 2, 0 );
	//���������Winsock dll�汾
	nErr = WSAStartup( wVersionRequested, &wsaData );
	if(nErr)
	{
		AfxMessageBox("����Winsock DLL ����");
		return;
	}
	if((g_hSocket = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) 
	{
		AfxMessageBox("����Socketʧ��");
		return;
	}
	
	//�󶨵�ַ
	if(bind(g_hSocket, (sockaddr*)&saServer, sizeof(SOCKADDR)) == SOCKET_ERROR)
	{
		AfxMessageBox("�󶨵�ַʧ��");
		return;
	}
	
	//�����ͻ�������
	if(listen(g_hSocket, 5) == SOCKET_ERROR) 
	{
		AfxMessageBox("�����ͻ�������ʧ��");
		return;
	}
	
	//����һ�߳��������ͻ�������
	AfxBeginThread(ServerThreadProc,0);
	//ʹ��ʼ��ť���
	GetDlgItem(IDC_START)->EnableWindow(FALSE);
	
}

void CServerDlg::OnEnd() 
{
	//�ر�Socket
	if(g_hSocket == NULL) return;
	VERIFY(closesocket(g_hSocket) != SOCKET_ERROR);
	g_hSocket = NULL;
	
	//ʹ��ʼ��ť��Ч
	GetDlgItem(IDC_START)->EnableWindow(TRUE);
}
